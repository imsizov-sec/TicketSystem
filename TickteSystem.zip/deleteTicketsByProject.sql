DELETE
FROM
	tickets
WHERE
	project_id = :projectId
