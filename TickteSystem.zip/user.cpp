#include "user.h"

User::User() {} // Пустой конструктор
