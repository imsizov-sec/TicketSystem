SELECT
    id,
    name
FROM
    statuses
