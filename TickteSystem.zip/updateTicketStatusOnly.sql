UPDATE
	tickets
SET
	status_id = :statusId
WHERE
	id = :ticketId
