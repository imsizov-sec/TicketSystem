// mailtest.h
#pragma once
void testMail();
