INSERT INTO ticket_files (
    ticket_id,
    file_name,
    relative_path
) VALUES (
    :ticketId,
    :fileName,
    :relativePath
)
