#ifndef UTILS_H
#define UTILS_H

#include <QString>

QString loadSqlQuery(const QString &filePath);

#endif // UTILS_H
