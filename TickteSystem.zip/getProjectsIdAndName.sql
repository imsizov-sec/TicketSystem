SELECT
    id,
    name
FROM
    projects
