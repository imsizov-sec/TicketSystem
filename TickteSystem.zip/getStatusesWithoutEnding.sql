SELECT
    id,
    name
FROM
    statuses
WHERE
	id != 3
