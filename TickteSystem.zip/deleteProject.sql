DELETE
FROM
    projects
WHERE
    id = :projectId
