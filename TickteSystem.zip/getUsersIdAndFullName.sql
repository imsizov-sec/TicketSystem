SELECT
    id,
    full_name
FROM
    users

