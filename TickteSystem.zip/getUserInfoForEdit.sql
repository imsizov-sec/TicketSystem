SELECT
	first_name,
	middle_name,
	last_name,
	email
FROM
	users
WHERE
	id = :id

