SELECT
    id,
    name
FROM
    trackers
